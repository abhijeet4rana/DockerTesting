resetItemsFromBrowserStorage();
const getBackendServerUrl = () => {
  return 'http://localhost:5000/api/v1/';
  const serverUrl = parseCookieForDomain();
  // return serverUrl;
  // For Local Development
  // return `http://${projectSubDomain}.api.prodeless.com:5002/api/v1/`;
};

const parseCookieInfo = () => {
  const parsedCookie = document.cookie
    .split(';')
    .map((v) => v.split('='))
    .reduce((acc, v) => {
      acc[decodeURIComponent(v[0].trim())] = decodeURIComponent(v[1] ? v[1].trim() : '');
      return acc;
    }, {});
  return parsedCookie;
};

const parseCookieForDomain = () => {
  const parsedCookie = parseCookieInfo();
  const apiDomainName = parsedCookie['apiDomainName'];
  const domain = parsedCookie['projectSeoName'];
  const environment = parsedCookie['environment'];

  //Check if request is coming from our domain
  const hostName = window.location.hostname;
  if (hostName.includes('drapcode.io')) {
    return `https://${domain}.api.${environment ? environment + '.' : ''}drapcode.io/api/v1/`;
  }

  if (apiDomainName && apiDomainName !== 'undefined' && apiDomainName !== undefined) {
    return `https://${apiDomainName}/api/v1/`;
  } else {
    return `https://${domain}.api.${environment ? environment + '.' : ''}drapcode.io/api/v1/`;
  }
};

function resetItemsFromBrowserStorage() {
  const RESET_SESSION_KEYS = '__resetK';
  let resetKeys = sessionStorage.getItem(RESET_SESSION_KEYS);
  console.log('🚀 ~ file: constant.js:37 ~ resetItemsFromBrowserStorage ~ resetKeys:', resetKeys);
  if (resetKeys) resetKeys = resetKeys.split(',');
  if (resetKeys) {
    if (Array.isArray(resetKeys) && resetKeys.length) {
      resetKeys.forEach((key) => sessionStorage.removeItem(key));
    }
  }

  const RESET_SESSION_KEYS_DETAIL_PAGE = '__resetK_dp';
  let resetKeysDetailPage = sessionStorage.getItem(RESET_SESSION_KEYS_DETAIL_PAGE);
  console.log(
    '🚀 ~ file: constant.js:47 ~ resetItemsFromBrowserStorage ~ resetKeysDetailPage:',
    resetKeysDetailPage,
  );
  if (resetKeysDetailPage) resetKeysDetailPage = resetKeysDetailPage.split(',');
  if (resetKeysDetailPage) {
    if (Array.isArray(resetKeysDetailPage) && resetKeysDetailPage.length) {
      resetKeysDetailPage.forEach((key) => sessionStorage.removeItem(key));
    }
  }
}

const imageServerUrl = () => {
  const parsedCookie = parseCookieInfo();
  const S3URL = parsedCookie['S3URL'];
  return `${S3URL}/`;
};
