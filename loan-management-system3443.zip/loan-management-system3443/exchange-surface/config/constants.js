export const serverDomains = ['staging', 'preview', 'sandbox', 'uat'];
export const uatEnvs = ['preview', 'sandbox', 'uat'];
