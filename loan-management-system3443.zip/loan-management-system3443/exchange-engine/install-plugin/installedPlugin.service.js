import { pluginCode } from 'drapcode-constant';
import { replaceValueFromSource } from 'drapcode-utility';
export const findInstalledPlugin = async (builderDB, query) => {
  const InstalledPlugin = builderDB.collection('plugins');
  return await InstalledPlugin.findOne(query);
};

export const findAllInstalledPlugin = async (builderDB, projectId) => {
  let InstalledPlugin = builderDB.collection('plugins');
  return await InstalledPlugin.find({ projectId }).toArray();
};
export const loadS3PluginConfig = async (builderDB, projectId, environment) => {
  const s3Plugin = await findInstalledPlugin(builderDB, { projectId, code: pluginCode.AWS_S3 });
  console.log('s3Plugin', s3Plugin);
  if (!s3Plugin) {
    return {
      region: process.env.AWS_S3_REGION,
      accessKeyId: process.env.AWS_ACCESS_KEY_ID,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
      bucket: process.env.AWS_S3_BUCKET,
    };
  }

  let { access_key, access_secret, bucket_name, region } = s3Plugin.setting;
  access_key = replaceValueFromSource(access_key, environment, null);
  access_secret = replaceValueFromSource(access_secret, environment, null);
  bucket_name = replaceValueFromSource(bucket_name, environment, null);
  region = replaceValueFromSource(region, environment, null);
  return {
    region,
    bucket: bucket_name,
    accessKeyId: access_key,
    secretAccessKey: access_secret,
  };
};
