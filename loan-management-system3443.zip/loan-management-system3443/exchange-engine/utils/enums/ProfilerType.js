export const API = 'API';
export const DB_REQUEST = 'DB_REQUEST';
export const COMPUTING = 'COMPUTING';
const ProfilerType = [API, DB_REQUEST, COMPUTING];
export default ProfilerType;
