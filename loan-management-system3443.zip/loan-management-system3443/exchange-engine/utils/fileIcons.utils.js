export const generateIcons = (type) => {
  let smallIcon;
  let mediumIcon;
  let largeIcon;
  switch (type) {
    case 'image/png':
    case 'image/jpeg':
    case 'image/gif':
      smallIcon = 'https://drapcode-static.s3.amazonaws.com/img/placeholder-img.png';
      mediumIcon = 'https://drapcode-static.s3.amazonaws.com/img/placeholder-img.png';
      largeIcon = 'https://drapcode-static.s3.amazonaws.com/img/placeholder-img.png';
      break;
    case 'application/zip':
      smallIcon = 'https://drapcode-static.s3.amazonaws.com/img/zip.png';
      mediumIcon = 'https://drapcode-static.s3.amazonaws.com/img/zip.png';
      largeIcon = 'https://drapcode-static.s3.amazonaws.com/img/zip.png';
      break;
    case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': //xlsx
    case 'application/vnd.ms-excel': //xls
      smallIcon = 'https://drapcode-static.s3.amazonaws.com/img/excel.png';
      mediumIcon = 'https://drapcode-static.s3.amazonaws.com/img/excel.png';
      largeIcon = 'https://drapcode-static.s3.amazonaws.com/img/excel.png   ';
      break;
    case 'application/pdf':
      smallIcon = 'https://drapcode-static.s3.amazonaws.com/img/pdf-file.png';
      mediumIcon = 'https://drapcode-static.s3.amazonaws.com/img/pdf-file.png';
      largeIcon = 'https://drapcode-static.s3.amazonaws.com/img/pdf-file.png';
      break;
    case 'text/csv':
      smallIcon = 'https://drapcode-static.s3.amazonaws.com/img/csv.png';
      mediumIcon = 'https://drapcode-static.s3.amazonaws.com/img/csv.png';
      largeIcon = 'https://drapcode-static.s3.amazonaws.com/img/csv.png';
      break;
    case 'application/msword': //doc
    case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document': //docx
      smallIcon = 'https://drapcode-static.s3.amazonaws.com/img/google-docs.png';
      mediumIcon = 'https://drapcode-static.s3.amazonaws.com/img/google-docs.png';
      largeIcon = 'https://drapcode-static.s3.amazonaws.com/img/google-docs.png';
      break;
    case 'text/plain':
      smallIcon = 'https://drapcode-static.s3.amazonaws.com/img/txt.png';
      mediumIcon = 'https://drapcode-static.s3.amazonaws.com/img/txt.png';
      largeIcon = 'https://drapcode-static.s3.amazonaws.com/img/txt.png';
      break;
    case 'application/rtf':
      smallIcon = 'https://drapcode-static.s3.amazonaws.com/img/rtf-file-symbol.png';
      mediumIcon = 'https://drapcode-static.s3.amazonaws.com/img/rtf-file-symbol.png';
      largeIcon = 'https://drapcode-static.s3.amazonaws.com/img/rtf-file-symbol.png';
      break;
    case 'text/html':
      smallIcon = 'https://drapcode-static.s3.amazonaws.com/img/html.png';
      mediumIcon = 'https://drapcode-static.s3.amazonaws.com/img/html.png';
      largeIcon = 'https://drapcode-static.s3.amazonaws.com/img/html.png';
      break;
    case 'audio/mpeg':
      smallIcon = 'https://drapcode-static.s3.amazonaws.com/img/placeholder-audio.png';
      mediumIcon = 'https://drapcode-static.s3.amazonaws.com/img/placeholder-audio.png';
      largeIcon = 'https://drapcode-static.s3.amazonaws.com/img/placeholder-audio.png';
      break;
    case 'video/mpeg': //mpg
    case 'video/x-flv': //flv
    case 'video/x-msvideo': //avi
      smallIcon = 'https://drapcode-static.s3.amazonaws.com/img/video.png';
      mediumIcon = 'https://drapcode-static.s3.amazonaws.com/img/video.png';
      largeIcon = 'https://drapcode-static.s3.amazonaws.com/img/video.png';
      break;
    case 'application/vnd.ms-powerpoint': //ppt
    case 'application/vnd.openxmlformats-officedocument.presentationml.presentation': //pptx
      smallIcon = 'https://drapcode-static.s3.amazonaws.com/img/powerpoint.png';
      mediumIcon = 'https://drapcode-static.s3.amazonaws.com/img/powerpoint.png';
      largeIcon = 'https://drapcode-static.s3.amazonaws.com/img/powerpoint.png';
      break;
    default:
      smallIcon = 'https://drapcode-static.s3.amazonaws.com/img/google-docs.png';
      mediumIcon = 'https://drapcode-static.s3.amazonaws.com/img/google-docs.png';
      largeIcon = 'https://drapcode-static.s3.amazonaws.com/img/google-docs.png';
      break;
  }
  return { smallIcon, mediumIcon, largeIcon };
};
