const EQUALS = 'EQUALS';
const NOT_EQUAL = 'NOT_EQUAL';
import moment from 'moment';
const numeral = require('numeral');
const v = require('voca');
const showdown = require('showdown');
import math from 'mathjs';
import { replaceDataValueIntoExpression, parseValueFromData } from 'drapcode-utility';
import DeviceDetector from 'device-detector-js';
import { processAuthentication } from '../developer/developer.service';
import { JSDOM } from 'jsdom';
import puppeteer from 'puppeteer';
import { findMyText } from '../email/email.service';
import {
  AIRTABLE,
  APP_WRITE,
  DIRECTUS,
  SALESFORCE,
  SUPABASE,
  XANO,
  XATA,
  notFieldForExport,
} from 'drapcode-constant';
//TODO: Need to load from s3 plugin
//DEBUG: Identified
//INFO: It is hard coded in production branch too
//TODO: Need to discuss

const IMAGE_SERVER_URL = 'https://webconnect-upload.s3.amazonaws.com/';
const deviceDetector = new DeviceDetector();

export const COLLECTION_NOT_EXIST_MSG = {
  code: 404,
  message: 'Collection not found with provided name',
};

export const NOT_FIELD_FOR_EXPORT = ['_data_source_rest_api_primary_id', ...notFieldForExport];
export const REQUEST_BODY_JSON_TYPES = [
  'CUSTOM',
  'FORM_DATA',
  'FORM_URL_ENCODED',
  'DEFAULT_FIELDS',
];
export const EXTERNAL_DATA_SOURCE_TYPES = [
  SUPABASE,
  AIRTABLE,
  APP_WRITE,
  DIRECTUS,
  SALESFORCE,
  XANO,
  XATA,
];

//TODO: Move to common
export const isEmptyObject = (object) => {
  return Object.keys(object).length === 0 && object.constructor === Object;
};

//TODO: Move to common
export const parseJsonString = (str) => {
  try {
    str = str
      .replace(/\\n/g, '\\n')
      .replace(/\\'/g, "\\'")
      .replace(/\\"/g, '\\"')
      .replace(/\\&/g, '\\&')
      .replace(/\\r/g, '\\r')
      .replace(/\\t/g, '\\t')
      .replace(/\\b/g, '\\b')
      .replace(/\\f/g, '\\f');
    // Remove non-printable and other non-valid JSON characters
    // eslint-disable-next-line no-control-regex
    str = str.replace(/[\u0000-\u0019]+/g, '');
    return JSON.parse(str);
  } catch (e) {
    console.error('Error: ', e);
    return {};
  }
};

//TODO: Move to common
const getSpecialCharectorReplacedExpression = (expression) => {
  return expression
    .replace(/##@@##@@##/g, ' ')
    .replace(/##@@##@@@@/g, '>')
    .replace(/@@@@##@@@@/g, '<')
    .replace(/U\+000A/g, '<br/>');
};

export const saltingRounds = 10;
export const JWT_SECRET = 'addjsonwebtokensecretherelikeQuiscustodietipsoscustodes';

export const getDerivedFieldData = (
  derivedFieldData,
  item,
  projectConstant,
  environments,
  collectionConstant,
) => {
  const functionDef = JSON.parse(derivedFieldData);
  const { parentFieldName } = functionDef;
  let textContent = '';
  if (parentFieldName) {
    textContent =
      item[parentFieldName] &&
      item[parentFieldName]
        .map((innerItem) => {
          return prepareFunction(
            functionDef,
            innerItem,
            projectConstant,
            environments,
            collectionConstant,
          );
        })
        .join(', ');
  } else {
    textContent = prepareFunction(
      functionDef,
      item,
      projectConstant,
      environments,
      collectionConstant,
    );
  }
  return textContent;
};

export const prepareFunction = (
  functionDef,
  field,
  user,
  envConstants,
  previousActionResponse = {},
  previousActionFormData = {},
) => {
  let formatType,
    restToLower,
    whitespace,
    noSplitopt,
    type,
    length,
    endopt,
    startLength,
    endLength,
    startString,
    endString,
    separator,
    refField,
    unixType,
    currency,
    maxFraction,
    index,
    match,
    refFieldType,
    condition,
    position,
    expression,
    indexNum = '';
  let offset = false;
  let args = [];
  functionDef.args.forEach((element) => {
    const { name, key } = element;
    const excludes = [
      'formatType',
      'restToLower',
      'whitespace',
      'type',
      'noSplitopt',
      'length',
      'endopt',
      'startLength',
      'endLength',
      'startString',
      'endString',
      'separator',
      'expression',
      'refField',
      'index',
      'match',
      'refFieldType',
      'condition',
      'unixType',
      'currency',
      'maxFraction',
      'position',
      'indexNum',
    ];

    if (name === 'formatType') {
      formatType = key;
    } else if (name === 'restToLower') {
      restToLower = key;
    } else if (name === 'whitespace') {
      whitespace = key;
    } else if (name === 'type') {
      type = key;
    } else if (name === 'noSplitopt') {
      noSplitopt = key;
    } else if (name === 'length') {
      length = key;
    } else if (name === 'endopt') {
      endopt = key;
    } else if (name === 'startLength') {
      startLength = key;
    } else if (name === 'endLength') {
      endLength = key;
    } else if (name === 'startString') {
      startString = key;
    } else if (name === 'endString') {
      endString = key;
    } else if (name === 'separator') {
      separator = key;
    } else if (name === 'expression') {
      expression = key;
    } else if (name === 'refField') {
      refField = key;
    } else if (name === 'index') {
      index = key;
    } else if (name === 'match') {
      match = key;
    } else if (name === 'refFieldType') {
      refFieldType = key;
    } else if (name === 'condition') {
      condition = key;
    } else if (name === 'unixType') {
      unixType = key;
    } else if (name === 'currency') {
      currency = key;
    } else if (name === 'maxFraction') {
      maxFraction = key;
    } else if (name === 'position') {
      position = key;
    } else if (name === 'indexNum') {
      indexNum = key;
    }

    let innerArgs = [];
    if (!excludes.includes(name)) {
      if (Array.isArray(key)) {
        key.forEach((k) => {
          let value = '';
          value = k.includes('.')
            ? getArgsFromKey(
                k,
                field,
                user,
                {},
                envConstants,
                {},
                previousActionResponse,
                previousActionFormData,
              )
            : field[k];
          innerArgs.push(value);
        });
        args.push(innerArgs);
      } else if (key === 'CURRENT_DATE_TIME') {
        args.push(key);
      } else if (key.includes('.')) {
        const value = getArgsFromKey(
          key,
          field,
          user,
          {},
          envConstants,
          {},
          previousActionResponse,
          previousActionFormData,
        );
        args.push(value);
      } else {
        if (['updatedAt', 'createdAt'].includes(key)) offset = true;
        args.push(field[key]);
      }
    }
  });
  const timezone = 0;
  switch (functionDef.functionType) {
    case 'CAPITALIZE':
      return capitalize(args[0], restToLower);
    case 'LOWER_CASE':
      return lowerCase(args[0]);
    case 'UPPER_CASE':
      return upperCase(args[0]);
    case 'SLUGIFY':
      return slugify(args[0]);
    case 'TRIM':
      return trim(args[0], whitespace, type);
    case 'TITLE_CASE':
      return titleCase(args[0], noSplitopt);
    case 'TRUNCATE':
      return truncate(args[0], length, endopt);
    case 'SUB_STRING':
      return substr(args[0], startLength, endLength);
    case 'STRING_JOIN':
      return strJoin(args[0], separator, startString, endString);
    case 'SPLIT_STRING':
      return splitString(args[0], separator, index, indexNum);
    case 'CUSTOM_SENTENCE':
      return evaluateCustomSentence(expression, field, user, envConstants);
    case 'ADDITION':
      return addition(formatType, { numbers: args[0] });
    case 'AVERAGE':
      return average(formatType, { numbers: args[0] });
    case 'MULTIPLY':
      return multiply(formatType, { numbers: args[0] });
    case 'DIVIDE':
      return divide(formatType, { number1: args[0], number2: args[1] });
    case 'CUSTOM_CALCULATION':
      return evaluateExpression(expression, field, user, formatType, envConstants);
    case 'CUSTOM_JS_LOGIC':
      return evaluateJSLogic(expression, field, user, envConstants);
    case 'SUBSTRACTION':
      return substraction(formatType, { numbers1: args[0], numbers2: args[1] });
    case 'COUNT':
      return count(args[0], condition, refField, match, refFieldType);
    case 'FIND_RECORD':
      return findRecord(args[0], refField, index);
    case 'FORMAT_DATE':
      return formatDate(formatType, args[0], timezone, unixType, offset);
    case 'DATE_DIFFERENCE':
      return dateDifference(formatType, args[0], args[1], timezone);
    case 'CURRENCY_FORMAT':
      return evaluateCurrency(formatType, args[0], currency, position, maxFraction);
    case 'MARKDOWN_TO_HTML':
      return markdownToHtml(args[0]);
    default:
      return '';
  }
};
//TODO: Move to common
const capitalize = function (str, restToLower) {
  return v.capitalize(str, restToLower === 'TRUE');
};
//TODO: Move to common
const lowerCase = function (str) {
  return v.lowerCase(str);
};
//TODO: Move to common
const upperCase = function (str) {
  return v.upperCase(str);
};
//TODO: Move to common
const slugify = function (str) {
  return v.slugify(str);
};
//TODO: Move to common
const trim = function (subject, whitespace, type) {
  if (type === 'LEFT') {
    return v.trimLeft(subject, whitespace);
  } else if (type === 'RIGHT') {
    return v.trimRight(subject, whitespace);
  } else {
    return v.trim(subject, whitespace);
  }
};
//TODO: Move to common
const titleCase = function (subject, noSplitopt) {
  return v.titleCase(subject, [noSplitopt]);
};
//TODO: Move to common
const truncate = function (subject, length, endopt) {
  return v.truncate(subject, length, endopt);
};
//TODO: Move to common
const substr = function (subject, startLength, endLength) {
  return v.substr(subject, startLength, endLength);
};

//TODO: Move to common
const strJoin = function (dataArr, separator, startString, endString) {
  separator = separator ? separator.replace(/##@@##@@##/g, ' ') : ' ';
  dataArr = Array.isArray(dataArr) ? dataArr : [dataArr];
  dataArr = dataArr.filter(Boolean);
  return `${startString ? startString.replace(/##@@##@@##/g, ' ') + separator : ''}${dataArr.join(
    separator,
  )}${endString ? separator + endString.replace(/##@@##@@##/g, ' ') : ''}`;
};

const markdownToHtml = function (subject) {
  const converter = new showdown.Converter({ tables: true });
  const html = converter.makeHtml(subject);
  return html;
};

const evaluateCustomSentence = function (expression, data, user, envConstants) {
  expression = expression ? getSpecialCharectorReplacedExpression(expression) : ' ';
  return replaceDataValueIntoExpression(expression, data, user, {}, envConstants);
};

//TODO: Move to common
const median = (arr = []) => arr.reduce((sume, el) => sume + el, 0) / arr.length;
//TODO: Move to common
const average = function (formatType, { numbers }) {
  return numeral(median([...numbers])).format(formatType ? formatType : '00.00');
};
//TODO: Move to common
const addition = function (formatType, { numbers }) {
  let sum = [...numbers].reduce((a, b) => a + b, 0);
  return numeral(sum).format(formatType ? formatType : '00.00');
};
//TODO: Move to common
const multiply = function (formatType, { numbers }) {
  let multipliedValue = [...numbers].reduce((a, b) => a * b, 0);
  return numeral(multipliedValue).format(formatType ? formatType : '00.00');
};

let add = (arr = []) => {
  return arr.reduce((a, b) => a + b, 0);
};
const substraction = function (formatType, { numbers1, numbers2 }) {
  const actNumber1 = Array.isArray(numbers1) ? add([...numbers1]) : numbers1;
  const actNumber2 = Array.isArray(numbers2) ? add([...numbers2]) : numbers2;
  const subtractedVal = actNumber1 - actNumber2;
  return numeral(subtractedVal).format(formatType ? formatType : '00.00');
};

const count = function (subject, condition, refField, match, refFieldType) {
  switch (condition) {
    case EQUALS:
      subject = subject.filter((sub) => {
        if (['dynamic_option', 'static_option'].includes(refFieldType)) {
          return sub[refField].includes(match);
        } else return false;
      });
      break;
    case NOT_EQUAL:
      subject = subject.filter((sub) => {
        if (['dynamic_option', 'static_option'].includes(refFieldType)) {
          return !sub[refField].includes(match);
        } else return false;
      });
      break;
  }
  return subject.length;
};

const divide = function (formatType, { number1, number2 }) {
  return numeral(math.divide(number1, number2)).format(formatType ? formatType : '00.00');
};
const evaluateExpression = function (expression, data, user, formatType, envConstants) {
  expression = expression ? getSpecialCharectorReplacedExpression(expression) : ' ';
  const replacedExpression = replaceDataValueIntoExpression(
    expression,
    data,
    user,
    {},
    envConstants,
  );
  try {
    return numeral(math.evaluate(replacedExpression)).format(formatType ? formatType : '00.00');
  } catch (err) {
    return '';
  }
};

const evaluateJSLogic = function (expression, data, user, envConstants) {
  expression = expression ? getSpecialCharectorReplacedExpression(expression) : ' ';
  const replacedExpression = replaceDataValueIntoExpression(
    expression,
    data,
    user,
    {},
    envConstants,
  );
  try {
    const replacedExpressionFunction = new Function(replacedExpression.toString());
    return replacedExpressionFunction();
  } catch (err) {
    return '';
  }
};

const getUserDetails = async (builderDB, db, projectId, token = null) => {
  const userDetails = await processAuthentication(builderDB, db, projectId, token);
  if (userDetails.code !== 200) {
    return {
      userName: null,
      user_uuid: null,
    };
  } else {
    return {
      userName: userDetails.data?.userName,
      user_uuid: userDetails.data?.uuid,
    };
  }
};

export const serverRequestDetails = async (builderDB, db, projectId, token, ip, device_agent) => {
  const deviceAgent = await deviceDetector.parse(device_agent);
  const userDetails = await getUserDetails(builderDB, db, projectId, token);

  return {
    ...userDetails,
    ip: ip || null,
    browser: deviceAgent || {},
    createdAt: new Date(),
  };
};

export const findForLog = async (db, collectionName, itemId) => {
  collectionName = collectionName.toString().toLowerCase();
  return await db.collection(collectionName).findOne({ uuid: itemId });
};

export const storeLogs = async (reqDetails, prev, current, type) => {
  let _obj = {
    ...reqDetails,
    previos: prev,
    current: current,
    action: type,
  };

  console.log(_obj, '================!!!!!!!!!!!!!!!!!1=============');
};

export const dynamicSort = (property) => {
  return (a, b) => {
    let result = 0;

    if (a[property] && b[property] && a[property] !== 'undefined' && b[property] !== 'undefined') {
      if (typeof a[property] === 'number' || typeof b[property] === 'number') {
        result = a[property] < b[property] ? -1 : a[property] > b[property] ? 1 : 0;
      } else {
        result =
          a[property].toLowerCase() < b[property].toLowerCase()
            ? -1
            : a[property].toLowerCase() > b[property].toLowerCase()
            ? 1
            : 0;
      }
    } else {
      result = 0;
    }

    return result;
  };
};

const findRecord = function (subject, refField, index) {
  if (index === 'FIRST_RECORD') return subject[0][refField];
  if (index === 'LAST_RECORD') return subject[subject.length - 1][refField];
};

const dateDifference = (formatType, datentime1, datentime2, timezone) => {
  let result = '';
  const dateExist = !datentime1 || !datentime2;
  const firstDate =
    datentime1 === 'CURRENT_DATE_TIME'
      ? moment().utcOffset(timezone)
      : moment(datentime1).utcOffset(timezone);
  const secondDate =
    datentime2 === 'CURRENT_DATE_TIME'
      ? moment().utcOffset(timezone)
      : moment(datentime2).utcOffset(timezone);
  const patterns = formatType.split(',');
  patterns.forEach((format, i) => {
    const diff = firstDate.diff(secondDate, format);
    if (diff < 0) {
      firstDate.subtract(diff, format);
    } else {
      secondDate.add(diff, format);
    }
    result =
      result +
      `${Math.abs(dateExist ? 0 : diff)} ${format.charAt(0).toUpperCase() + format.slice(1)}${
        i === patterns.length - 1 ? '' : ','
      } `;
  });
  return result;
};

const evaluateCurrency = function (formatType, subject, currency, position, maxFraction) {
  try {
    if (!subject) subject = 0;
    if (!maxFraction && maxFraction !== 0) maxFraction = 2;
    const multiplier = Math.pow(10, maxFraction || 0);
    const digit = Math.round(subject * multiplier) / multiplier;
    subject = new Intl.NumberFormat(formatType, { minimumFractionDigits: maxFraction }).format(
      digit,
    );
    switch (position) {
      case 'FRONT':
        return `${currency}${subject}`;
      case 'FRONT_WITH_SPACE':
        return `${currency} ${subject}`;
      case 'BACK':
        return `${subject}${currency}`;
      case 'BACK_WITH_SPACE':
        return `${subject} ${currency}`;
      default:
        return '';
    }
  } catch (error) {
    return '';
  }
};

const getArgsFromKey = (
  key,
  field,
  loggedInUserData,
  projectConstant = {},
  envConstants,
  collectionConstant = {},
  previousActionResponse,
  previousActionFormData,
) => {
  let value = '';
  if (key.includes('current_user.')) {
    const userKey = key.split('.')[1];
    value = loggedInUserData[userKey];
  } else if (key.includes('current_user_reference_field.')) {
    const [userRefFieldName, newKey] = key.replace('current_user_reference_field.', '').split('.');
    const userRefField = loggedInUserData?.[userRefFieldName];
    value = userRefField ? userRefField[0]?.[newKey] : '';
  } else if (key.includes('createdBy.')) {
    const newKey = key.split('.')[1];
    const createdBy = field?.createdBy;
    value = createdBy[0]?.[newKey];
  } else if (key.includes('environment_variable.')) {
    const envConstantName = key.split('environment_variable.')[1];
    value = envConstants.find((constant) => constant.name === envConstantName).value;
  } else if (key.includes('RF::')) {
    const [refFieldName, newKey] = key.replace('RF::', '').split('.');
    const refField = field?.[refFieldName];
    value = refField[0]?.[newKey];
  } else if (key.includes('PC::')) {
    console.log('projectConstant :>> ', projectConstant);
    value = '';
  } else if (key.includes('CC::')) {
    console.log('collectionConstant :>> ', collectionConstant);
    value = '';
  } else if (key.includes('current_session.')) {
    const sessionKey = key.split('.')[1];
    value = previousActionResponse?.[sessionKey];
  } else if (key.includes('form_data_session.')) {
    const sessionKey = key.split('.')[1];
    value = previousActionFormData?.[sessionKey];
  } else {
    value = '';
  }
  return value;
};

const formatDate = function (formatType, datentime, timezone, unixType, offset = false) {
  let formatDateNTime =
    unixType && unixType === 'SEC' ? moment(datentime * 1000) : moment(datentime);
  if (offset) {
    formatDateNTime = formatDateNTime.utcOffset(timezone);
  }
  if (formatType === 'FROM_NOW') {
    return datentime ? formatDateNTime.fromNow() : '';
  }
  return datentime ? formatDateNTime.format(formatType) : '';
};

const splitString = (subject, separator, index, indexNum) => {
  if (!subject) return '';
  separator = separator ? separator.replace(/##@@##@@##/g, ' ') : ' ';
  const stringArr = subject.split(separator);
  if (index === 'FIRST_ITEM') {
    indexNum = 0;
  } else if (index === 'LAST_ITEM') {
    indexNum = stringArr.length - 1;
  } else if (index === 'NTH_ITEM') {
    indexNum = indexNum - 1;
  }
  return stringArr[indexNum];
};

export const isJsonStringOfArray = (bodyJSON, wrapJsonDataInArray) => {
  let jsonString = bodyJSON ?? '';
  if (jsonString) {
    let bodyJsonString = '';
    if (jsonString && jsonString.includes("'")) {
      bodyJsonString = jsonString.replaceAll("'", '"');
      bodyJsonString = JSON.stringify(bodyJsonString);
    } else {
      bodyJsonString = JSON.stringify(jsonString);
    }

    // Fix JSON to Parsable JSON String
    const parsableJsonString = bodyJsonString ? fixDynamicNeedleJsonString(bodyJsonString) : '';
    let bodyJsonObj = parsableJsonString ? parseJsonString(parsableJsonString) : '';
    bodyJsonObj = bodyJsonObj ? parseJsonString(bodyJsonObj) : {};
    wrapJsonDataInArray = bodyJsonObj ? Array.isArray(bodyJsonObj) : false;
  }
  return wrapJsonDataInArray;
};

export const addDynamicDataIntoElement = (content, css, collectionName, itemId, itemData) => {
  const htmlRegex =
    /<(br|basefont|hr|input|source|frame|param|area|meta|!--|col|link|option|base|img|wbr|!DOCTYPE).*?>|<(a|abbr|acronym|address|applet|article|aside|audio|b|bdi|bdo|big|blockquote|body|button|canvas|caption|center|cite|code|colgroup|command|datalist|dd|del|details|dfn|dialog|dir|div|dl|dt|em|embed|fieldset|figcaption|figure|font|footer|form|frameset|head|header|hgroup|h1|h2|h3|h4|h5|h6|html|i|iframe|ins|kbd|keygen|label|legend|li|map|mark|menu|meter|nav|noframes|noscript|object|ol|optgroup|output|p|pre|progress|q|rp|rt|ruby|s|samp|script|section|select|small|span|strike|strong|style|sub|summary|sup|table|tbody|td|textarea|tfoot|th|thead|time|title|tr|track|tt|u|ul|var|video).*?<\/\2>/i;

  const jsDom = new JSDOM(content, { includeNodeLocations: true });
  const { window } = jsDom;
  const { document } = window;
  const style = document.createElement('style');
  style.innerHTML = css;
  document.head.appendChild(style);

  const dataField = `data-${collectionName}`;
  const dataURLField = `data-url-${collectionName}`;
  const dataImageTag = `data-img-src-${collectionName}`;

  if (collectionName && itemId && itemData) {
    let hyperLinks = document.querySelectorAll('[data-path-collection-name]');
    let imageElements = document.querySelectorAll('[' + dataImageTag + ']');
    let textContentElements = document.querySelectorAll('[' + dataField + ']');
    let urlContentElements = document.querySelectorAll('[' + dataURLField + ']');

    if (textContentElements || imageElements || hyperLinks || urlContentElements) {
      // Text
      textContentElements.forEach((textElement) => {
        let fieldName = textElement.getAttribute(dataField);
        let type = textElement.getAttribute('type');
        if (fieldName.includes('"') && 'functionType' in JSON.parse(fieldName)) {
          textElement.innerHTML = getDerivedFieldData(fieldName, itemData);
        } else {
          if (type === 'reference' || type === 'multi_reference' || type === 'belongsTo') {
            const { nestedFieldName } = JSON.parse(textElement.getAttribute('metaData'));
            if (!fieldName.includes('.')) {
              fieldName = fieldName + '.' + nestedFieldName;
            }
          }
          const fieldType = textElement.getAttribute('data-field-type');
          const value = parseValueFromData(itemData, fieldName) || '';
          if (htmlRegex.test(value)) {
            textElement.innerHTML = value;
          } else if (fieldType === 'boolean') {
            textElement.textContent = value ? 'Yes' : 'No';
          } else {
            textElement.textContent = value;
          }
        }
        textElement.style.display = 'block';
      });
      // Links
      hyperLinks.forEach((element) => {
        const fieldName = element.getAttribute('data-path-field-name');
        if (fieldName) {
          if (
            !(
              element.hasAttribute('data-gjs') &&
              element.getAttribute('data-gjs') === 'data-table-link'
            )
          ) {
            const href = element.getAttribute('href');
            let fieldHref = fieldName ? parseValueFromData(itemData, fieldName) : '';

            if (fieldHref && typeof fieldHref === 'string' && fieldHref.includes(',')) {
              fieldHref = fieldHref.split(', ');
              fieldHref = fieldHref[0];
            }

            const replaceHref = href.replace(fieldName, fieldHref);
            element.setAttribute('href', replaceHref);
          }
        }
      });
      // URL
      urlContentElements.forEach((element) => {
        const fieldType = element.getAttribute('data-field-type');
        if (fieldType !== 'file') {
          const fieldName = element.getAttribute(dataURLField);
          const href = element.getAttribute(dataURLField);
          const replaceHref = href.replace(fieldName, parseValueFromData(itemData, fieldName));
          element.setAttribute('href', replaceHref);
        }
      });
      // Image
      imageElements.forEach((imageElement) => {
        const fieldName = imageElement.getAttribute(dataImageTag);
        let itemImageData = fieldName ? parseValueFromData(itemData, fieldName) : '';
        if (Array.isArray(itemImageData)) {
          itemImageData = itemImageData[0];
        }
        let imageSrcUrl;
        if (itemImageData) {
          if (typeof itemImageData === 'object') {
            const imageKey = itemImageData.key;
            if (imageKey) imageSrcUrl = IMAGE_SERVER_URL + imageKey;
          } else if (typeof itemImageData === 'string' && itemImageData.startsWith('http')) {
            imageSrcUrl = itemImageData;
          }
          imageElement.src = imageSrcUrl;
        }
      });
    }
  }
  content = jsDom.serialize();
  return content;
};

export const convertHtmlToPdf = async (html, options) => {
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox'],
  });
  const page = await browser.newPage();
  await page.setContent(html, { waitUntil: 'domcontentloaded' });
  await page.emulateMediaType('screen');
  const pdfBuffer = await page.pdf(options);
  await browser.close();
  return pdfBuffer;
};

export const fixDynamicNeedleJsonString = (
  jsonString,
  returnNeedlesArray = false,
  nonStringNeedles,
) => {
  const regExp = new RegExp('(?<needle>(?:(?<!"){{[a-zA-Z0-9-_:.]*}}))'); // Match the pattern: {{key}}
  let newJsonString = jsonString;
  if (newJsonString) {
    let matchValue = newJsonString.match(regExp);
    if (matchValue) {
      const { groups } = matchValue || '';
      const { needle } = groups || '';
      if (returnNeedlesArray) {
        nonStringNeedles.push(needle);
      }
      if (typeof newJsonString === 'string' && newJsonString.includes('\\"')) {
        newJsonString = newJsonString.replace(regExp, `\\"$1\\"`);
      } else {
        newJsonString = newJsonString.replace(regExp, '"$1"');
      }
      return fixDynamicNeedleJsonString(newJsonString, returnNeedlesArray, nonStringNeedles);
    }
  }
  return newJsonString;
};

export const replaceNonStringValue = function (needle, replacement, haystackText) {
  console.log(
    '🚀 ~ replaceNonStringValue ~ replacement:',
    replacement,
    ' ~ typeof',
    typeof replacement,
  );
  const match = new RegExp(needle, 'ig');
  if (replacement && replacement.length > 0) {
    return haystackText.replace(match, replacement);
  } else {
    if (typeof replacement === 'undefined') {
      replacement = null;
    }
    return haystackText.replace(match, replacement);
  }
};

export const replaceNeedleValueForNewData = (needle, newData, dataOfItem) => {
  const { dtoExternalApiType, dtoNonStringNeedles } = DTO_EXTERNAL_API || '';
  //Format: {{NEEDLE}},'Value to Replace','JSON String'
  if (EXTERNAL_DATA_SOURCE_TYPES.includes(dtoExternalApiType)) {
    if (dtoNonStringNeedles.includes(needle)) {
      newData = replaceNonStringValue(needle, dataOfItem, newData);
    } else {
      newData = findMyText(needle, dataOfItem ? dataOfItem.toString() : '', newData);
    }
  } else {
    newData = findMyText(needle, dataOfItem ? dataOfItem.toString() : '', newData);
  }
  return newData;
};

export const extractNeedlesFromString = (jsonString, isNotStringNeedles = false) => {
  let needleList = [];
  if (jsonString) {
    if (isNotStringNeedles) {
      needleList = jsonString.match(/(?:(?<!"){{[a-zA-Z0-9-_:.]*}})/gm)?.map((needle) => needle); // Extract all Non-String needles with pattern {{needle}}
    } else {
      needleList = jsonString.match(/(?:(?<="){{[a-zA-Z0-9-_:.]*}})/gm)?.map((needle) => needle); // Extract all String needles with pattern "{{needle}}"
    }
  }
  return needleList;
};

/**
 * DTOs
 */
export const DTO_EXTERNAL_API = {
  dtoExternalApiType: '',
  dtoIsExternalSource: false,
  dtoNonStringNeedles: [],
};

export const prepareCurrentUserParamsValue = (currentUserParams, currentUser) => {
  //Write Code to Extract value and pass it for further processing
  currentUserParams.forEach((param) => {
    param.value = currentUser[param.key];
  });
};

export const addParams = (url, params, currentUserParams, collectionParamsValue) => {
  currentUserParams.forEach((param) => {
    if (url.includes(`${param.key}`)) {
      url = url.replace(`${param.key}`, param.value);
    }
  });
  if (Array.isArray(collectionParamsValue)) {
    collectionParamsValue.forEach((param) => {
      if (url.includes(`{{${param.key}}}`)) {
        url = url.replace(`{{${param.key}}}`, param.value);
      }
    });
  } else if (Object.keys(collectionParamsValue).length > 0) {
    Object.entries(collectionParamsValue).forEach(([key, value]) => {
      if (url.includes(`{{${key}}}`)) {
        url = url.replace(`{{${key}}}`, value);
      }
    });
  }
  let paramString = '';
  for (let i = 0; i < params.length; i++) {
    const currParam = params[i];
    if (currParam.key && currParam.key != '' && currParam.value && currParam.value != '') {
      const paramValue = extractValue(currParam.value, currentUserParams);
      if (paramValue) {
        currParam.value = paramValue;
      }
      if (paramString !== '' || url.includes('?')) {
        paramString += `&${currParam.key}=${currParam.value}`;
      } else {
        paramString = `?${currParam.key}=${currParam.value}`;
      }
    }
  }

  url += paramString;
  return url;
};

export const addHeaderValue = (objHeader, headers, currentUserParams) => {
  for (let i = 0; i < headers.length; i++) {
    const header = headers[i];
    const paramValue = extractValue(header.value, currentUserParams);
    if (paramValue) {
      header.value = paramValue;
    }
    objHeader[header.key] = header.value;
  }
};

export const extractValue = (key, currentUserParams) => {
  const paramObj = currentUserParams.find((obj) => {
    return `${obj.key}` === key;
  });
  return paramObj ? paramObj.value : '';
};
