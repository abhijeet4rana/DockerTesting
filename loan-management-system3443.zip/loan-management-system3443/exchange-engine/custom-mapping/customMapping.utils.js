// Todo: Can be moved to common modules
import { mergeObjects } from 'external-api-util';
import { getDataTransferObject } from '../external-api/external-api.service';

export const transformDataToMapping = (
  data,
  mapping,
  collection,
  user = {},
  tenant = {},
  sessionValue = {},
  sessionFormValue = {},
  environment = {},
  projectConstants = {},
) => {
  const { collectionFields, collectionDerivedFields, collectionConstants } = collection;
  const currentUserDerivedFields = {};
  const finalData = [];
  let commonObj = {
    formData: {},
    collectionFields,
    collectionConstants,
    collectionDerivedFields,
    environment,
    projectConstants,
  };
  data.forEach((item) => {
    const customJsonDataObj = {
      collectionItemId: item?.uuid ? item.uuid : '',
      dataToSendToExternalApi: item,
      ...commonObj,
    };
    const dataTransferObject = getDataTransferObject(
      { headers: mapping, url: '', params: [] },
      item,
      customJsonDataObj,
      user,
      tenant,
      sessionFormValue,
      currentUserDerivedFields,
      sessionValue,
    );
    const mappedData = mergeObjects(
      mapping,
      item,
      user,
      tenant,
      sessionValue,
      environment.constants,
      sessionFormValue,
      dataTransferObject,
    );
    finalData.push(mappedData);
  });
  return finalData;
};
