import express from 'express';
import {
  addUserWithProvider,
  loginWithProvider,
  loginUserWithExternalAPI,
  resetPassword,
  changePassword,
  loginUserWithToken,
  addAnonymousUser,
  getTenantByTenantId,
  getUserSettingByUserSettingId,
  updateTenantPermission,
  updateUserPermission,
  loginWithTwoFactor,
  updateUserSettingsPermission,
  loginUserWithOAuth2,
  loginUserWithFacebook,
  loginUserWithTwitter,
} from './user.controller';
import { interceptLogger } from 'drapcode-utility';
import { verifyJwt } from './jwtUtils';

const loginPluginRoute = express.Router();

loginPluginRoute.post('/user/:provider?', interceptLogger, addUserWithProvider);
loginPluginRoute.post('/anonymous-user', interceptLogger, addAnonymousUser);
loginPluginRoute.post('/login/:provider?', interceptLogger, loginWithProvider);
loginPluginRoute.post('/two-auth-verification', interceptLogger, loginWithTwoFactor);
loginPluginRoute.post(
  '/login/otp/external-api/:collectionItemId?',
  interceptLogger,
  loginUserWithExternalAPI,
);
loginPluginRoute.post('/login-with-token', interceptLogger, loginUserWithToken);
loginPluginRoute.post('/reset-password/', [interceptLogger, verifyJwt], resetPassword);
loginPluginRoute.post('/change-passoword/', [interceptLogger, verifyJwt], changePassword);
loginPluginRoute.get('/tenant/:tenantId', getTenantByTenantId);
loginPluginRoute.get('/userSetting/:userSettingId', getUserSettingByUserSettingId);
loginPluginRoute.post(
  '/tenant/:tenantId/permissions',
  [interceptLogger, verifyJwt],
  updateTenantPermission,
);
loginPluginRoute.post(
  '/user/:userId/permissions',
  [interceptLogger, verifyJwt],
  updateUserPermission,
);
loginPluginRoute.post(
  '/user-settings/:userSettingsId/permissions',
  [interceptLogger, verifyJwt],
  updateUserSettingsPermission,
);

loginPluginRoute.post('/loginUserWithOAuth2', loginUserWithOAuth2);
loginPluginRoute.post('/loginUserWithFacebook', loginUserWithFacebook);
loginPluginRoute.post('/loginUserWithTwitter', loginUserWithTwitter);

export default loginPluginRoute;
