import { pluginCode } from 'drapcode-constant';
import jwt from 'jsonwebtoken';
import passport from 'passport';
import { findInstalledPlugin } from '../install-plugin/installedPlugin.service';
import { findOneItemByQuery } from '../item/item.service';
import { userCollectionName } from './loginUtils';

const JWT_SECRET_KEY = 'addjsonwebtokensecretherelikeQuiscustodietipsoscustodes';
const jwtOptions = {
  expiresIn: '30m',
  algorithm: 'HS256', //default: HS256
};

export const issueJWTToken = (userData) => {
  if (userData) {
    const payload = {
      sub: userData.username || userData.userName || userData.email,
      iat: Date.now(),
    };
    const signedToken = jwt.sign(payload, JWT_SECRET_KEY, jwtOptions);
    return {
      token: 'Bearer ' + signedToken,
      expires: jwtOptions.expiresIn,
    };
  }
};
export const verifyToken = (jwtToken) => {
  try {
    if (jwtToken.startsWith('Bearer ')) {
      jwtToken = jwtToken.substring(7, jwtToken.length);
    }
    return jwt.verify(jwtToken, JWT_SECRET_KEY, jwtOptions);
  } catch (e) {
    console.error('e: verify token ', e.message);
    return null;
  }
};

export async function verifyJwt(req, res, next) {
  console.log('Verifying JWT Authentication for secure: >> 1');
  if (req.originalUrl.includes('finder')) return next(); // if filter api
  let origin = req.get('origin');
  if (origin && origin.includes('admin')) return next();
  /**
   * Check if login plugin installed or not.
   */
  const { headers, builderDB, db, projectId } = req;
  const loginPlugin = await findInstalledPlugin(builderDB, {
    code: pluginCode.LOGIN,
    projectId,
  });
  if (!loginPlugin) {
    return next();
  }
  console.log('I have installed login plugin: >>2');
  if (!headers.authorization) {
    return res.status(401).send({ code: 401, message: 'No token provided.' });
  }
  passport.authenticate('jwt', { session: false }, async function (err, user, info) {
    if (err) {
      return next(err);
    }
    if (!user) {
      info.code = 403;
      return res.status(403).send(info);
    }
    const userFromDb = await findOneItemByQuery(db, userCollectionName, {
      userName: user.sub,
    });
    if (!userFromDb) {
      return res.status(401).send({ code: 403, message: 'Invalid token.' });
    }
    req.user = userFromDb; // Forward user information to the next middleware
    next();
  })(req, res, next);
}

export async function verifyJwtForOpen(req, res, next) {
  console.log('Verifying JWT Authentication for Open: >> 1');
  const { headers, db } = req;
  const authorizationHeader = headers.authorization;
  if (authorizationHeader) {
    const token = authorizationHeader.split(' ')[1];
    try {
      const payload = await verifyToken(token);
      req.user = payload;
      passport.authenticate('jwt', { session: false }, async function (err, user, info) {
        if (err) {
          return next(err);
        }
        if (!user) {
          info.code = 403;
          return res.status(403).send(info);
        }
        const userFromDb = await findOneItemByQuery(db, userCollectionName, {
          userName: user.sub,
        });
        if (!userFromDb) {
          return res.status(401).send({ code: 403, message: 'Invalid token.' });
        }
        req.user = userFromDb; // Forward user information to the next middleware
        next();
      })(req, res, next);
    } catch (err) {
      console.error('verifyJwtForOpen err', err);
      throw new Error(err);
    }
  } else {
    next();
  }
}
