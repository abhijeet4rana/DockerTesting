import { pluginCode } from 'drapcode-constant';
import { generateUsername } from 'unique-username-generator';
import {
  checkCollectionByName,
  findCollectionsByQuery,
  findOneService,
} from '../collection/collection.service';
import {
  convertPasswordTypeFields,
  convertSingleItemToList,
  validateItemCollection,
  convertStringDataToObject,
  convertAutoGenerateTypeFields,
  findOneItemByQuery,
  findItemByIdAfterCollection,
} from '../item/item.service';
import { v4 as uuidv4 } from 'uuid';
import { roleCollectionName, userCollectionName } from './loginUtils';
import { PROVIDER_TYPE, signUpWithBackendless, signUpWithXano } from './authProviderUtil';
import { customInsertOne } from '../utils/utils';
import { findInstalledPlugin } from '../install-plugin/installedPlugin.service';
import _, { isArray } from 'lodash';
import axios from 'axios';
import {
  getEncryptedReferenceFieldsQuery,
  processItemEncryptDecrypt,
  validateEmail,
} from 'drapcode-utility';
import { getProjectEncryption } from '../middleware/encryption.middleware';
const Chance = require('chance');
const chance = new Chance();
const DUMMY_EMAIL_DOMAIN = '@email.com';

export const saveUser = async (builderDB, dbConnection, projectId, userData) => {
  const collectionData = await checkCollectionByName(builderDB, projectId, userCollectionName);
  console.log('collectionData saveUser', collectionData);
  if (!collectionData) {
    return { code: 404, data: `Collection not found with provided name` };
  }

  validateUserData(collectionData, userData);
  userData.password = userData.password ? userData.password : chance.string({ length: 10 });
  console.log('==> saveUser userData :>> ', userData);
  const errorJson = await validateItemCollection(
    dbConnection,
    collectionData,
    userData,
    null,
    false,
  );
  console.error('errorJson saveUser', errorJson);
  if (Object.keys(errorJson).length !== 0) {
    if (errorJson.field)
      return {
        code: 409,
        message: 'Validation Failed',
        data: errorJson.field,
      };
  } else {
    userData = await convertAutoGenerateTypeFields(
      builderDB,
      dbConnection,
      projectId,
      collectionData,
      userData,
    );
    userData = await convertPasswordTypeFields(
      builderDB,
      dbConnection,
      projectId,
      collectionData,
      userData,
    );
    userData = await convertSingleItemToList(collectionData, userData);
    userData = await convertStringDataToObject(collectionData, userData);
    userData.createdAt = new Date();
    userData.updatedAt = new Date();
    if (!_.get(userData, 'uuid')) {
      userData.uuid = uuidv4();
    }

    let dbCollection = await dbConnection.collection(userCollectionName);
    const savedItem = await customInsertOne(dbCollection, userData);
    // eslint-disable-next-line no-prototype-builtins
    if (savedItem) {
      await copyPermissionsInUser(dbConnection, savedItem);
    }

    return {
      code: 201,
      message: 'Item Created Successfully',
      data: savedItem ? savedItem : {},
    };
  }
};

export const saveUserWithProvider = async (
  builderDB,
  dbConnection,
  projectId,
  userData,
  provider,
  environment,
) => {
  const collectionData = await checkCollectionByName(builderDB, projectId, userCollectionName);
  if (!collectionData) {
    return { code: 404, data: `Collection not found with provided name` };
  }

  validateUserData(collectionData, userData);
  userData.password = userData.password ? userData.password : chance.string({ length: 10 });
  console.log('==> saveUserWithProvider userData :>> ', userData);
  const errorJson = await validateItemCollection(
    dbConnection,
    collectionData,
    userData,
    null,
    false,
  );
  console.log('errorJson', errorJson);
  if (Object.keys(errorJson).length !== 0 && errorJson.field) {
    return {
      code: 409,
      message: 'Validation Failed',
      data: errorJson.field,
    };
  }

  let role = '';
  if (userData.userRoles && userData.userRoles.length > 0) {
    console.log('==> saveUserWithProvider userData.userRoles :>> ', userData.userRoles);
    console.log(
      '==> saveUserWithProvider isArray(userData.userRoles) :>> ',
      isArray(userData.userRoles),
    );
    let roleName = isArray(userData.userRoles) ? userData.userRoles[0] : userData.userRoles;
    role = await findOneItemByQuery(dbConnection, roleCollectionName, {
      name: roleName,
    });
  }
  console.log('==> saveUserWithProvider userData role :>> ', role);

  if (!role || role.length === 0) {
    return {
      code: 409,
      message: 'Validation Failed',
      data: 'The provided role does not exist. Please verify and try again.',
    };
  }

  // eslint-disable-next-line no-prototype-builtins
  if (userData && userData.hasOwnProperty('tenantRoleMapping') && userData.tenantRoleMapping) {
    console.log(
      '==> saveUserWithProvider userData.tenantRoleMapping :>> ',
      userData.tenantRoleMapping,
    );
    const tenantRoleMappingRole = userData.tenantRoleMapping;
    console.log('🚀 ~ file: user.service.js:164 ~ tenantRoleMappingRole:', tenantRoleMappingRole);
    // eslint-disable-next-line no-prototype-builtins
    if (userData && userData.hasOwnProperty('tenantId') && userData.tenantId.length > 0) {
      console.log('🚀 ~ file: user.service.js:168 ~ userData.tenantId:', userData.tenantId);
      const tenantRoleMap = [];
      tenantRoleMap.push({
        tenantId: userData.tenantId[0],
        role: tenantRoleMappingRole,
        createdAt: new Date(),
      });
      userData.tenantRoleMapping = tenantRoleMap;
    }
    // eslint-disable-next-line no-prototype-builtins
    if (userData && userData.hasOwnProperty('userSettingId') && userData.userSettingId.length > 0) {
      console.log(
        '🚀 ~ file: user.service.js:168 ~ userData.userSettingId:',
        userData.userSettingId,
      );
      const tenantRoleMap = [];
      tenantRoleMap.push({
        userSettingId: userData.userSettingId[0],
        role: tenantRoleMappingRole,
        createdAt: new Date(),
      });
      userData.tenantRoleMapping = tenantRoleMap;
    }
  }

  let extraDocument = {};
  let uuid = '';
  if (provider) {
    let authResponse = await processAuthSignup(
      builderDB,
      projectId,
      provider,
      userData,
      environment,
    );
    if (!authResponse.success) {
      console.log('Sending Sending');
      return {
        code: authResponse.status,
        message: authResponse.message,
        data: authResponse.message,
      };
    }

    if (provider === PROVIDER_TYPE.XANO) {
      const { authToken, id, name } = authResponse.data;
      extraDocument = { authToken };
      if (name) {
        extraDocument = { ...extraDocument, name };
      }
      uuid = id;
    } else if (provider === PROVIDER_TYPE.BACKENDLESS) {
      const { authToken, ownerId, name } = authResponse.data;
      extraDocument = { authToken };
      if (name) {
        extraDocument = { ...extraDocument, name };
      }
      uuid = ownerId;
    }
  } else {
    uuid = uuidv4();
  }

  userData = await convertAutoGenerateTypeFields(
    builderDB,
    dbConnection,
    projectId,
    collectionData,
    userData,
  );
  userData = await convertPasswordTypeFields(
    builderDB,
    dbConnection,
    projectId,
    collectionData,
    userData,
  );
  userData = await convertSingleItemToList(collectionData, userData);
  userData = await convertStringDataToObject(collectionData, userData);
  userData.createdAt = new Date();
  userData.updatedAt = new Date();
  userData.uuid = uuid;

  userData = { ...userData, ...extraDocument };
  console.log('userData', userData);

  let dbCollection = await dbConnection.collection(userCollectionName);
  const savedItem = await customInsertOne(dbCollection, userData);
  // eslint-disable-next-line no-prototype-builtins
  if (savedItem) {
    await copyPermissionsInUser(dbConnection, savedItem);
  }

  return {
    code: 201,
    message: 'Item Created Successfully',
    data: savedItem ? savedItem : {},
  };
};

export const saveAnonymousUser = async (builderDB, dbConnection, projectId, userData) => {
  const collectionData = await checkCollectionByName(builderDB, projectId, userCollectionName);
  if (!collectionData) {
    return { code: 404, data: `Collection not found with provided name` };
  }

  if (!userData.userName || userData.userName === 'anonymous-user-login') {
    userData.userName = generateUsername('', 4);
  }
  validateUserData(collectionData, userData);
  userData.password = userData.password ? userData.password : chance.string({ length: 10 });
  console.log('==> saveAnonymousUser userData :>> ', userData);
  const errorJson = await validateItemCollection(
    dbConnection,
    collectionData,
    userData,
    null,
    false,
  );
  console.error('errorJson', errorJson);
  if (Object.keys(errorJson).length !== 0 && errorJson.field) {
    return {
      code: 409,
      message: 'Validation Failed',
      data: errorJson.field,
    };
  }

  let role = '';
  if (userData.userRoles && userData.userRoles.length > 0) {
    console.log('==> saveAnonymousUser userData.userRoles :>> ', userData.userRoles);
    console.log('==> saveAnonymousUser isArray :>> ', isArray(userData.userRoles));
    let roleName = isArray(userData.userRoles) ? userData.userRoles[0] : userData.userRoles;
    role = await findOneItemByQuery(dbConnection, roleCollectionName, {
      name: roleName,
    });
  }
  console.log('==> saveUserWithProvider userData role :>> ', role);
  if (!role || role.length === 0) {
    return {
      code: 409,
      message: 'Validation Failed',
      data: 'The provided role does not exist. Please verify and try again.',
    };
  }

  let extraDocument = {};
  let uuid = uuidv4();
  userData = await convertAutoGenerateTypeFields(
    builderDB,
    dbConnection,
    projectId,
    collectionData,
    userData,
  );
  userData = await convertPasswordTypeFields(
    builderDB,
    dbConnection,
    projectId,
    collectionData,
    userData,
  );
  userData = await convertSingleItemToList(collectionData, userData);
  userData = await convertStringDataToObject(collectionData, userData);
  userData.createdAt = new Date();
  userData.updatedAt = new Date();
  userData.uuid = uuid;

  userData = { ...userData, ...extraDocument };

  let dbCollection = await dbConnection.collection(userCollectionName);
  const savedItem = await customInsertOne(dbCollection, userData);
  // eslint-disable-next-line no-prototype-builtins
  if (savedItem) {
    await copyPermissionsInUser(dbConnection, savedItem);
  }

  return {
    code: 201,
    message: 'Item Created Successfully',
    data: savedItem ? savedItem : {},
  };
};

const processAuthSignup = async (builderDB, projectId, provider, userData, environment) => {
  let authData = null;
  let authResponse = null;
  let providerCode = '';
  switch (provider) {
    case PROVIDER_TYPE.XANO:
      providerCode = pluginCode.LOGIN_WITH_XANO;
      break;
    case PROVIDER_TYPE.BACKENDLESS:
      providerCode = pluginCode.LOGIN_WITH_BACKENDLESS;
      break;
    default:
      providerCode = '';
      break;
  }
  if (!providerCode) {
    return { success: false, status: 405, message: 'No provider found' };
  }

  const plugin = await findInstalledPlugin(builderDB, {
    code: providerCode,
    projectId,
  });

  if (!plugin) {
    return { success: false, status: 405, message: 'Provider Plugin is not installed' };
  }

  if (provider === PROVIDER_TYPE.XANO) {
    authData = { email: userData.userName, password: userData.password };
    authResponse = await signUpWithXano(environment, plugin.setting, authData);
  } else if (provider === PROVIDER_TYPE.BACKENDLESS) {
    authData = { email: userData.userName, password: userData.password };
    authResponse = await signUpWithBackendless(environment, plugin.setting, authData);
  }
  return authResponse;
};

export const validateUserData = (collectionData, userData) => {
  let { fields } = collectionData ? collectionData : '';
  const requireFields = fields ? fields.filter((field) => field.required) : [];

  for (const field of requireFields) {
    if (!userData[`${field.fieldName}`]) {
      console.log('==> validateUserData field is required :>> ', field.fieldTitle.en);
      //Handling the missing required fields
      if (field.fieldName === 'userName') {
        if (userData && userData['email'] && !userData['userName']) {
          let usernameFieldValue = userData['email'];
          if (userData['email'].includes('@')) {
            usernameFieldValue = userData['email'].split('@')[0];
          }
          userData['userName'] = usernameFieldValue;
        }
      } else if (field.fieldName === 'email') {
        if (userData && userData['userName'] && !userData['email']) {
          let emailFieldValue = userData['userName'];
          if (!userData['userName'].includes('@')) {
            emailFieldValue += DUMMY_EMAIL_DOMAIN;
          }
          userData['email'] = emailFieldValue;
        }
      }
    }
  }
};

export const updateTenantPermissionsService = async (
  builderDB,
  dbConnection,
  projectId,
  tenantId,
  permissions,
) => {
  let tenant = null;
  if (tenantId) {
    const multiTenantPlugin = await findInstalledPlugin(builderDB, {
      code: pluginCode.MULTI_TENANT_SAAS,
      projectId,
    });
    if (multiTenantPlugin) {
      const { multiTenantCollection } = multiTenantPlugin?.setting || '';
      if (multiTenantCollection) {
        const collectionData = await findOneService(builderDB, { uuid: multiTenantCollection });
        if (collectionData) {
          const query = { uuid: tenantId };
          const collectionName = collectionData.collectionName.toString().toLowerCase();
          let dbCollection = await dbConnection.collection(collectionName);

          tenant = await dbCollection.findOne(query);
          const tenantPermission = tenant.permissions || [];

          Object.keys(permissions).forEach((permission) => {
            if (permissions[permission]) {
              if (!tenantPermission.includes(permission)) tenantPermission.push(permission);
            } else {
              _.remove(tenantPermission, (tPermission) => tPermission === permission);
            }
          });

          let newValues = { $set: { permissions: tenantPermission } };
          let data = await dbCollection.findOneAndUpdate(query, newValues, {
            new: true,
          });
          if (!data || (data.lastErrorObject && !data.lastErrorObject.updatedExisting)) {
            return { code: 404, message: 'Item not found with provided id', data: {} };
          }
          tenant = await findItemByIdAfterCollection(dbConnection, collectionData, tenantId, null);
          tenant = tenant && tenant.data ? tenant.data : '';
        }
      }
    }
  }
  console.log('tenant permission updated', tenant);
  return tenant;
};
export const updateUserPermissionsService = async (
  builderDB,
  dbConnection,
  projectId,
  userId,
  permissions,
) => {
  let user = null;
  if (userId) {
    const query = { uuid: userId };
    let dbCollection = await dbConnection.collection(userCollectionName);

    user = await dbCollection.findOne(query);
    const userPermissions = user.permissions || [];

    Object.keys(permissions).forEach((permission) => {
      if (permissions[permission]) {
        if (!userPermissions.includes(permission)) userPermissions.push(permission);
      } else {
        _.remove(userPermissions, (tPermission) => tPermission === permission);
      }
    });

    let newValues = { $set: { permissions: userPermissions } };
    let data = await dbCollection.findOneAndUpdate(query, newValues, {
      new: true,
    });
    if (!data || (data.lastErrorObject && !data.lastErrorObject.updatedExisting)) {
      return { code: 404, message: 'Item not found with provided id', data: {} };
    }
  }
  console.log('user permission updated ', user);
  return user;
};

export const updateUserSettingsPermissionsService = async (
  builderDB,
  dbConnection,
  projectId,
  userSettingId,
  permissions,
) => {
  let userSetting = null;
  if (userSettingId) {
    const multiTenantPlugin = await findInstalledPlugin(builderDB, {
      code: pluginCode.MULTI_TENANT_SAAS,
      projectId,
    });
    if (multiTenantPlugin) {
      const { userSettingsCollection } = multiTenantPlugin?.setting || '';
      if (userSettingsCollection) {
        const collectionData = await findOneService(builderDB, { uuid: userSettingsCollection });
        if (collectionData) {
          const query = { uuid: userSettingId };
          const collectionName = collectionData.collectionName.toString().toLowerCase();
          let dbCollection = await dbConnection.collection(collectionName);

          userSetting = await dbCollection.findOne(query);
          const userSettingsPermission = userSetting.permissions || [];

          Object.keys(permissions).forEach((permission) => {
            if (permissions[permission]) {
              if (!userSettingsPermission.includes(permission))
                userSettingsPermission.push(permission);
            } else {
              _.remove(userSettingsPermission, (tPermission) => tPermission === permission);
            }
          });

          let newValues = { $set: { permissions: userSettingsPermission } };
          let data = await dbCollection.findOneAndUpdate(query, newValues, {
            new: true,
          });
          if (!data || (data.lastErrorObject && !data.lastErrorObject.updatedExisting)) {
            return { code: 404, message: 'Item not found with provided id', data: {} };
          }
          userSetting = await findItemByIdAfterCollection(
            dbConnection,
            collectionData,
            userSettingId,
            null,
          );
          userSetting = userSetting && userSetting.data ? userSetting.data : '';
        }
      }
    }
  }
  console.log('user setting permission updated', userSetting);
  return userSetting;
};

export const copyPermissionsInUser = async (dbConnection, user) => {
  try {
    if (!user) {
      return user;
    }
    console.log('copyPermissionsInUser user', user);
    const { userRoles, uuid } = user;
    console.log('copyPermissionsInUser userRoles', userRoles);

    let role = '';
    if (userRoles && userRoles.length > 0) {
      console.log('==> copyPermissionsInUser isArray(userRoles) :>> ', isArray(userRoles));
      let roleName = isArray(userRoles) ? userRoles[0] : userRoles;
      role = await findOneItemByQuery(dbConnection, roleCollectionName, {
        name: roleName,
      });
    }

    console.log('copyPermissionsInUser role', role);
    if (!role) {
      console.log('Since no role details so return');
      return user;
    }
    console.log('We have role permission so return');
    let rolePermissions = role.permissions;
    console.log('copyPermissionsInUser rolePermissions', rolePermissions);
    if (!rolePermissions || rolePermissions.length === 0) {
      return user;
    }

    const query = { uuid };
    let dbCollection = await dbConnection.collection(userCollectionName);
    let newValues = { $set: { permissions: rolePermissions } };
    let data = await dbCollection.findOneAndUpdate(query, newValues, {
      new: true,
    });

    return data;
  } catch (error) {
    console.error('error', error);
  }
};

export const getUserFromOAuthAccessToken = async (
  builderDB,
  db,
  projectId,
  pluginOptions,
  accessToken,
  authUserRole,
  type,
) => {
  const { userInfoUrl, userUniqueField, defaultRole } = pluginOptions;
  if (type === 'SIGNUP' && !authUserRole) {
    let signUpRole = await findOneItemByQuery(db, roleCollectionName, {
      uuid: defaultRole,
    });
    authUserRole = signUpRole ? signUpRole.name : authUserRole;
  }
  const userInfoResponse = await axios.get(userInfoUrl, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  const authUser = userInfoResponse.data;
  const uniqueId = authUser[userUniqueField];
  const authEmail = authUser['email'];
  const query = {
    $or: [{ email: { $regex: `^${authEmail}$`, $options: 'i' } }, { uuid: uniqueId }],
  };
  let user = await findOneItemByQuery(db, userCollectionName, query);
  if (!user) {
    if (type === 'LOGIN')
      return { status: 404, error: { message: `User doesn't exist. Please Sign up First.` } };
    const newUser = {
      email: validateEmail(authEmail) ? authEmail : '',
      userName: authEmail,
      uuid: uniqueId,
      password: chance.string({ length: 10 }),
      userRoles: authUserRole,
    };
    const userResponse = await saveUser(builderDB, db, projectId, newUser);
    user = userResponse.data;
  }
  let role = '';
  if (user.userRoles && user.userRoles.length > 0) {
    role = await findOneItemByQuery(db, roleCollectionName, {
      name: user.userRoles[0],
    });
  }
  let result = { status: 200, accessToken, user, role: role ? role.uuid : '', error: null };
  return result;
};

export const getUserFromFacebookAccessToken = async (
  builderDB,
  db,
  projectId,
  pluginOptions,
  accessToken,
  authUserRole,
  type,
) => {
  const { defaultRole } = pluginOptions;
  if (type === 'SIGNUP' && !authUserRole) {
    let signUpRole = await findOneItemByQuery(db, roleCollectionName, {
      uuid: defaultRole,
    });
    authUserRole = signUpRole ? signUpRole.name : authUserRole;
  }

  const userInfoResponse = await axios.get('https://graph.facebook.com/me', {
    params: {
      fields: 'id,name,email',
      access_token: accessToken,
    },
  });

  const authUser = userInfoResponse.data;
  const uniqueId = authUser.id;
  const authEmail = authUser.email;
  const query = {
    $or: [{ email: { $regex: `^${authEmail}$`, $options: 'i' } }, { uuid: uniqueId }],
  };
  let user = await findOneItemByQuery(db, userCollectionName, query);

  if (!user) {
    if (type === 'LOGIN') {
      return { status: 404, error: { message: `User doesn't exist. Please Sign up First.` } };
    }

    const newUser = {
      email: validateEmail(authEmail) ? authEmail : '',
      userName: authEmail,
      uuid: uniqueId,
      password: chance.string({ length: 10 }),
      userRoles: [authUserRole],
    };

    const userResponse = await saveUser(builderDB, db, projectId, newUser);
    user = userResponse.data;
  }

  let role = '';
  if (user.userRoles && user.userRoles.length > 0) {
    role = await findOneItemByQuery(db, roleCollectionName, {
      name: user.userRoles[0],
    });
  }

  let result = { status: 200, accessToken, user, role: role ? role.uuid : '', error: null };
  return result;
};

export const getUserFromTwitterAccessToken = async (
  builderDB,
  db,
  projectId,
  pluginOptions,
  profile,
  authUserRole,
  type,
) => {
  const { defaultRole } = pluginOptions;
  if (type === 'SIGNUP' && !authUserRole) {
    let signUpRole = await findOneItemByQuery(db, roleCollectionName, {
      uuid: defaultRole,
    });
    authUserRole = signUpRole ? signUpRole.name : authUserRole;
  }
  const { id, username } = profile;
  const query = { $or: [{ username: username }, { uuid: id }] };
  let user = await findOneItemByQuery(db, userCollectionName, query);

  if (!user) {
    if (type === 'LOGIN') {
      return { status: 404, error: { message: `User doesn't exist. Please Sign up First.` } };
    }

    const newUser = {
      userName: username,
      uuid: id,
      password: chance.string({ length: 10 }),
      userRoles: [authUserRole],
    };

    const userResponse = await saveUser(builderDB, db, projectId, newUser);
    user = userResponse.data;
  }

  let role = '';
  if (user.userRoles && user.userRoles.length > 0) {
    role = await findOneItemByQuery(db, roleCollectionName, {
      name: user.userRoles[0],
    });
  }

  let result = { status: 200, user, role: role ? role.uuid : '', error: null };
  return result;
};

export const decryptUser = async (builderDB, projectId, user) => {
  const collectionData = await findOneService(builderDB, {
    collectionName: userCollectionName,
    projectId,
  });
  if (collectionData) {
    const { enableEncryption, encryption } = await getProjectEncryption(projectId, builderDB);
    if (enableEncryption && encryption) {
      const collectionDataFields = collectionData ? collectionData.fields : [];
      const query = getEncryptedReferenceFieldsQuery(collectionDataFields, projectId);
      const encrypedRefCollections = await findCollectionsByQuery(builderDB, query);
      const cryptResponse = await processItemEncryptDecrypt(
        user,
        collectionDataFields,
        encryption,
        true,
        encrypedRefCollections,
      );
      user = cryptResponse;
      console.log('*** Decrypted ~ user:', user);
    }
  }
  return user;
};
