export const serverDomains = ['staging', 'preview', 'sandbox', 'uat'];
