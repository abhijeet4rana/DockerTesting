import { AppError } from 'drapcode-utility';
import { findItemById } from '../item/item.service';
import { addDynamicDataIntoElement, convertHtmlToPdf } from '../utils/appUtils';
import { findTemplate } from './snippet.service';
import { addLocalizationDataIntoElements } from '../project/build-utils';

export const showTemplateContent = async (req, res, next) => {
  try {
    const { builderDB, projectId, query, params } = req;
    const { lang } = query;
    const { templateId } = params;
    const response = await findTemplate(builderDB, { uuid: templateId });
    delete response.content['nocode-assets'];
    response.content = await replaceLocalizationContent(
      builderDB,
      projectId,
      lang,
      response.content,
    );
    res.status(200).send(response.content);
  } catch (e) {
    console.error('show template content ~ error:', e);
    next(e);
  }
};
// TODO: can be refactor or removed
export const findTemplateByUuid = async (req, res, next) => {
  try {
    const { builderDB, projectId, query, params } = req;
    const { lang } = query;
    const { templateId } = params;
    const response = await getTemplate(builderDB, projectId, lang, { uuid: templateId });
    res.status(200).send(response);
  } catch (e) {
    console.error('find template by uuid ~ error:', e);
    next(e);
  }
};

export const findModalTemplate = async (req, res, next) => {
  try {
    const { builderDB, projectId, query, params } = req;
    const { lang } = query;
    const { templateId } = params;
    const response = await getTemplate(builderDB, projectId, lang, {
      snippetType: 'MODAL',
      uuid: templateId,
    });
    res.status(200).send(response);
  } catch (e) {
    console.error('find modal template ~ error:', e);
    next(e);
  }
};

export const downloadPDFTemplateContent = async (req, res, next) => {
  try {
    const { builderDB, projectId, db, query, params, body } = req;
    const { lang } = query;
    const { templateId } = params;
    const { collectionName, itemId, pdfDownloadOptions } = body;
    const { marginTop, marginBottom, marginLeft, marginRight, printBackground, format } =
      pdfDownloadOptions;
    const pdfTemplate = await findTemplate(builderDB, { uuid: templateId });

    let pdfContent = pdfTemplate.content;
    const pdfCollectionName = pdfTemplate.collectionId;
    pdfContent = await replaceLocalizationContent(builderDB, projectId, lang, pdfContent);
    const item = await findItemById(builderDB, db, projectId, collectionName, itemId);

    let scriptRegex = /<script\b[^>]*>([\s\S]*?)<\/script>/gm;
    let pdfContentHtml = pdfContent['nocode-html']
      ? pdfContent['nocode-html'].replace(scriptRegex, '')
      : '';
    let pdfContentCss = pdfContent['nocode-css'] ? pdfContent['nocode-css'] : '';
    if (pdfCollectionName === collectionName) {
      pdfContentHtml = addDynamicDataIntoElement(
        pdfContentHtml,
        pdfContentCss,
        collectionName,
        itemId,
        item.data,
      );
      let margin = {};
      if (marginTop) margin.top = `${marginTop}cm`;
      if (marginBottom) margin.bottom = `${marginBottom}cm`;
      if (marginLeft) margin.left = `${marginLeft}cm`;
      if (marginRight) margin.right = `${marginRight}cm`;
      const pdfOptions = {
        printBackground,
        preferCSSPageSize: true,
        format: format ? format : 'A4',
        margin,
      };
      const pdfBuffer = await convertHtmlToPdf(pdfContentHtml, pdfOptions);
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `${collectionName}_${itemId}`);
      res.status(200).send(pdfBuffer);
    } else {
      const error = new AppError('Collection is not similar to Template Collection');
      res.status(400).send(error);
    }
  } catch (e) {
    console.error('download PDF template content ~ error:', e);
    next(e);
  }
};

const replaceLocalizationContent = async (builderDB, projectId, lang, content) => {
  const localizations = await fetchLocalization(builderDB, projectId);
  console.log('localizations', localizations);
  const localization =
    lang && !['null', 'undefined'].includes(lang) && !['null', 'undefined'].includes(typeof lang)
      ? localizations.find((local) => local.language === lang)
      : localizations.find((local) => local.isDefault);
  content['nocode-html'] = addLocalizationDataIntoElements(content['nocode-html'], localization);
  return content;
};

const fetchLocalization = async (builderDB, projectId) => {
  const Localization = builderDB.collection('localization');
  return Localization.find({ projectId }).toArray();
};

const getTemplate = async (builderDB, projectId, lang, query) => {
  const response = await findTemplate(builderDB, query);
  if (response?.content) {
    response.content = await replaceLocalizationContent(
      builderDB,
      projectId,
      lang,
      response.content,
    );
  }
  return response;
};
